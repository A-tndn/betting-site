<!-- admin_footer.php -->

<footer class="admin-footer">
    <div class="container">
        <div class="footer-content">
            <p>&copy; <?php echo date("Y"); ?> Your Admin Panel</p>
            <p>All rights reserved.</p>
            <p>For support, contact: support@yourdomain.com</p>
        </div>
    </div>
</footer>
